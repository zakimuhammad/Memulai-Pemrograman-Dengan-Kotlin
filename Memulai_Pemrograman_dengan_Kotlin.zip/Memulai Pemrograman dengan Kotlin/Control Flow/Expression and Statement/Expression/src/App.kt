// main function
fun main() {
    val openOffice = 7
    val now = 8
    val office = if (now > openOffice) "Office already open" else "office close"

    println(office)
}